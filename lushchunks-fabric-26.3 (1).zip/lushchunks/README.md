# Lush Chunks (Fabric, Minecraft 26.3)

Clientseitige Mod, die Chunks mit **Lush-Caves-Biom** erkennt und per **Chunk-Overlay** markiert.

## Voraussetzungen

- Minecraft 26.3, Fabric Loader 0.19.5+, Fabric API 0.165.0+26.3
- Java 25, Gradle 9.6+ (Loom 1.17)

## Bauen

```
gradle wrapper --gradle-version 9.6.0   # einmalig, erzeugt ./gradlew
./gradlew build                          # Jar in build/libs/
./gradlew runClient                      # Testclient
```

Aktuelle Versionen von Loom, Loader und Fabric API stehen auf https://fabricmc.net/develop
(bei Bedarf in `gradle.properties` anpassen).

## Fuer Modrinth: die richtige Datei

Modrinth akzeptiert nur die gebaute **.jar**, keine ZIP mit Quellcode.
Nach `./gradlew build` liegt in `build/libs/`:

- `lushchunks-1.0.0.jar` -> **diese Datei hochladen**
- `lushchunks-1.0.0-sources.jar` -> nicht hochladen

Ohne lokales Java 25: Projekt auf GitHub pushen. Der Workflow `.github/workflows/build.yml`
baut die Jar automatisch (Reiter Actions -> Artifact `lushchunks-jar`).

Version-Formular auf Modrinth: Loader **Fabric**, Spielversion **26.3**, Umgebung **Client**,
Abhaengigkeit **Fabric API** (erforderlich).

## Bedienung

- Taste **L** schaltet das Overlay um (aenderbar unter Steuerung -> Sonstiges).
- Befehle (clientseitig):
  - `/lushchunks` Status
  - `/lushchunks toggle` an/aus
  - `/lushchunks nearest` naechster Lush-Chunk mit Koordinaten
  - `/lushchunks rescan` Cache leeren und neu scannen
  - `/lushchunks style box|plane|both` Overlay-Stil
  - `/lushchunks ontop` Sichtbarkeit durch Waende umschalten
  - `/lushchunks radius <1-32>` Overlay-Radius in Chunks

## Funktionsweise

Der Client kennt die Biome aller geladenen Chunks. Jeder Chunk wird im 4x4x4-Biomraster
ueber die komplette Welthoehe abgetastet (max. 1536 Abfragen). Ab `minLushCells` Zellen
mit `minecraft:lush_caves` gilt der Chunk als Lush-Chunk. Gescannt wird verteilt ueber
mehrere Ticks, naechste Chunks zuerst.

Das Overlay nutzt vanillas Gizmo-System (`Gizmos.cuboid` / `Gizmos.rect`):

- **box**: Kastenumriss ueber die Hoehe, in der Lush-Zellen liegen
- **plane**: gefuellte Flaeche auf Spielerhoehe
- **both** (Standard): beides

Hinweis: Es werden nur Chunks erkannt, die der Server an den Client gesendet hat
(Render-Distanz). Der Scan-Radius wird davon begrenzt.

## Konfiguration

`config/lushchunks.properties` (Farben als ARGB-Hex):

| Schluessel | Standard | Bedeutung |
| --- | --- | --- |
| enabled | true | Mod aktiv |
| scanRadius | 16 | Scan-Radius in Chunks |
| overlayRadius | 12 | Zeichen-Radius in Chunks |
| minLushCells | 3 | Mindestzahl Lush-Zellen je Chunk |
| maxScansPerTick | 6 | Chunks pro Tick |
| style | BOTH | BOX, PLANE, BOTH |
| alwaysOnTop | true | durch Waende sichtbar |
| strokeWidth | 2.0 | Linienbreite |
| strokeColor | FF7CFC00 | Linienfarbe |
| fillColor | 3355FF77 | Fuellfarbe |

## Falls der Build auf 26.3 Fehler meldet

26.3 ist neu und das Rendering aendert sich haeufig. Die Stellen, die sich am ehesten aendern:

1. `LushChunksClient`: `LevelRenderEvents.BEFORE_GIZMOS` (Alternativen: `END_EXTRACTION`, `DEBUG_RENDER`),
   `KeyMapping.Category.MISC` und der `KeyMapping`-Konstruktor.
2. `LushOverlay`: `Gizmos.cuboid`, `Gizmos.rect`, `GizmoStyle.stroke/strokeAndFill`, `setAlwaysOnTop()`.
3. `LushScanner`: `level.getMinY()`, `level.getHeight()`, `level.hasChunk(x, z)`.
4. `build.gradle`: `loom_version` in `gradle.properties` (z. B. `1.17-SNAPSHOT` oder `1.18-SNAPSHOT`).
